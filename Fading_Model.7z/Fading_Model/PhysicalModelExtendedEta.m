clear all
clc

% Extended Eta-Mu fading part

mx = 7; % Número de Clusters em x
my = 3; % Número de Clusters em y
sx2 = 0.2; % Variância em x
sy2 = 1.3; % Variância em y
NF = 5e6; % Número frames

% inPhase components
X = sum(normrnd(0,sqrt(sx2/mx),[NF mx]).^2,2);
% Quadrature components
Y = sum(normrnd(0,sqrt(sy2/my),[NF my]).^2,2);

% Physical Gain Model
R = sqrt(X+Y);

% Calculated parameters
p = mx/my;
eta = sx2/sy2;
mu = (mx+my)/2;
E = (1+eta)/(1+p);
rc = sqrt(sx2+sy2);

% Extended eta-mu pdf
C = 2*(mu*E)^mu*(p/eta)^(mu*p/(1+p))/gamma(mu)/rc^(2*mu);
PDF =@(r) C*r.^(2*mu-1).*exp(-mu*E*r.^2/rc^2).*...
            hypergeom(mu*p/(1+p),mu,mu*E*(eta-p)*r.^2/eta/rc^2);

% Normalized Histogram
[FR,XR] = histnorm(R(:),1e2);
r = linspace(0,max(R(:)),1e2);
% Checking Curves
figure(1)
plot(r,PDF(r),...
     XR,FR,'--')
title('Extended \eta-\mu')

%%
clc

% Proposed fading part

ms = 10.24; % Inverse Nakagami parameter

% Inverse Nakagami samples
Sh = inverseNaka(ms,NF);

% Proposed gain samples
G = sqrt(Sh).*R;

PDFG =@(g) proposedEF(eta,mu,E,p,rc,ms,g);

% Normalized Histogram
[FG,XG] = histnorm(G(:),1e2);
g = linspace(0,max(G(:)),1e2);
% Checking Curves
figure(2)
plot(g,PDFG(g),'x',...
     XG,FG,'--')
title('Proposed Model')


















