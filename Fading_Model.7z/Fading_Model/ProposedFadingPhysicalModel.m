clear all
clc

NF = 5e5; % Número frames
ms = 10.5; % Inverse Nakagami parameter
mx = 3; % Número de Clusters em x
my = 2; % Número de Clusters em y
sx2 = .5; % Variância em x
sy2 = .5; % Variância em y

% Inverse Nakagami samples
Sh = inverseNaka(ms,NF);

% inPhase components
X = sum(normrnd(0,sqrt(sx2/mx),[NF mx]).^2,2);
% Quadrature components
Y = sum(normrnd(0,sqrt(sy2/my),[NF my]).^2,2);

% Physical Gain Model
R = sqrt(X+Y).*sqrt(Sh);

% Calculated parameters
p = mx/my;
eta = sx2/sy2;
mu = (mx+my)/2;
E = (1+eta)/(1+p);
rc = sqrt(sx2+sy2);


% Proposed Model PDF
PDF =@(r) proposedEF(eta,mu,E,p,rc,ms,r);

% Normalized Histogram
[FR,XR] = histnorm(R(:),1e2);
r = linspace(0,max(R(:)),1e2);
% Checking Curves
figure(1)
plot(r,PDF(r),'k',...
     XR,FR,'g--',...
     'linewidth',1.5)
title('Proposed Model')
legend('Theoretical','Simulated')
