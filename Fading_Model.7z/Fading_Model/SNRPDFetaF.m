function [S] = SNRPDFetaF(eta,mu,p,ga,ms,g)

E = (1+eta)/(1+p);

C = (mu*E)^mu*(ms-1)^ms*ga^(ms)*(p/eta)^(mu*p/(1+p))/beta(mu,ms);

fg =@(g) mu*E*g+(ms-1)*ga;

PDF =@(g) C*hypergeom([mu*p/(1+p) mu+ms],mu,mu*E*(eta-p)*g./fg(g)/eta).*...
            g.^(mu-1)./(fg(g).^(mu+ms));

S = PDF(g);

end