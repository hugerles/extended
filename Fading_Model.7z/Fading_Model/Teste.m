clear all
clc

eta = 1.5;
mu = 2;
p = 1.5;
ms = 10;
NF = 1e4;
rc = 1;
tic
g = extendedEtaF(eta,mu,rc,p,ms,NF);
toc

%%

ga = 2;
G =@(g) SNRPDFetaF(eta,mu,p,ga,ms,g);

SNR = ga*g.^2;
[GG,FG] = histnorm(SNR,1.5e2);
r = linspace(min(SNR),max(SNR),1e2);
figure(1)
plot(r,G(r),...
     FG,GG,'--',...
     'linewidth',1.5)