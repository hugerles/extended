function g = beaulieu(m,la,O,M,K,NF,Tc)
% Fun��o para gera��o das vari�veis aleat�rias da envolt�ria
% com distribui��o de Beaulieu-Xie
% M = N�mero de APs
% K = n�mero de UEs
% NF = n�mero de frames
% Tc = tempo de coer�ncia
% O = omega (pot�ncia da vari�vel aleat�ria)
% la = lambda (par�metro da distribui��o)
% m = par�metro da distribui��o

PDF =@(r) (2.*m./(O.*la.^(m-1))).*...
          exp(-m.*la.*la./O).*...
          exp(-m.*r.*r./O).*...
          besseli(m-1,2.*m.*la.*r./O).*...
          r.^m;

y = PDF(0:0.001:10);
mx = real(max(y));
if mx > 10
    mx = 10;
end

g = [];
while length(g) <= M*K*NF
    x1 = random('unif',0,2*pi,[1 M*K*NF]);
    y = random('unif',0,mx,[1 M*K*NF]);
    [~,x] = find(y <= PDF(x1));
        g = cat(2,g,x1(x));
end


g = g(1:M*K*NF); % Limitando o tamanho do vetor 
g = repelem(g,Tc); % Repeti��o para tempo de coer�ncia
g = reshape(g,NF*Tc,M,K); % Mudando a forma do vetor
g = permute(g,[2 3 1]); % Permutando a ordem do vetor

% g = squeeze(g);

% [fx,x] = histnorm(g(:),1e2);
% e = 0:0.001:max(g);
% max(g)
% figure(132)
% plot(e,PDF(e),'r',...
%      x,fx,'bx',...
%      'linewidth',1.5)

end
