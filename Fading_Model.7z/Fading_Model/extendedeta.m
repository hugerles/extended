function g = extendedeta(eta,mu,E,rc,p,NF,Tc)
% Função para geração das variáveis aleatórias da envoltória
% com distribuição de extended eta
% NF = número de frames
% Tc = tempo de coerência
% rc = potência da variável aleatória
% mu = número de agrupamentos de multipercurso
% eta = parâmetro da distribuição
% p = parâmetro que indica desbalanceamento em mu


C = 2*(mu*E)^mu*(p/eta)^(mu*p/(1+p))/gamma(mu)/rc^(2*mu);
PDF =@(r) C*r.^(2*mu-1).*exp(-mu*E*r.^2/rc^2).*...
            hypergeom(mu*p/(1+p),mu,mu*E*(eta-p)*r.^2/eta/rc^2);




y = PDF(0:0.01:10);
mx = real(max(y));
if mx > 10
    mx = 10;
end

g = [];
while length(g) <= NF
    x1 = random('unif',0,2*pi,[1 NF]);
    y = random('unif',0,mx,[1 NF]);
    [~,x] = find(y <= PDF(x1));
        g = cat(2,g,x1(x));
end


g = g(1:NF); % Limitando o tamanho do vetor 
g = repelem(g,Tc); % Repetição para tempo de coerência
% g = reshape(g,NF*Tc,M,K); % Mudando a forma do vetor
% g = permute(g,[2 3 1]); % Permutando a ordem do vetor

g = squeeze(g);

[fx,x] = histnorm(g(:),1e2);
e = 0:0.001:max(g);

figure(132)
plot(e,PDF(e),'r',...
     x,fx,'bx',...
     'linewidth',1.5)

end
