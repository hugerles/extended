function [pdf] = proposedEF(eta,mu,E,p,rc,ms,r)

C = 2*(mu*E)^mu*(ms-1)^ms*rc^(2*ms)*(p/eta)^(mu*p/(1+p))/beta(mu,ms);

fr =@(r) mu*E*r.^2+(ms-1)*rc^2;

PDF =@(r) C*hypergeom([mu*p/(1+p) mu+ms],mu,mu*E*(eta-p)*r.^2./fr(r)/eta).*...
            r.^(2*mu-1)./(fr(r).^(mu+ms));

pdf = PDF(r);

end