function [Pb] = AsPEBetaF(eta,mu,p,ms,ga,theta,phi)

E = (1+eta)/(1+p);

Pb = theta*gamma(mu+0.5)*(2*mu*E./ga/(ms-1)/phi).^mu*...
     (p/eta)^(mu*p/(1+p))/2/sqrt(pi)/beta(mu,ms)/mu;


end