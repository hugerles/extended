function [C] = CapEF(eta,mu,ms,p,ga,Nt)

E = (1+eta)/(1+p);

id =@(q) pochhammer(mu*p/(1+p),q)*(mu*E*(eta-p)./ga/(ms-1)/eta).^q.*...
         meijerG([1-ms-q-mu -mu-q],1-mu-q,[0 -mu-q -mu-q],[],mu*E./ga/(ms-1))./...
         factorial(q)/pochhammer(mu,q);

C = zeros(1,length(ga));
for n = 0:Nt
    C = C + id(n);
end

C = C.*(mu*E./ga/(ms-1)).^mu*(p/eta)^(mu*p/(1+p))/log(2)/gamma(mu)/gamma(ms);

end