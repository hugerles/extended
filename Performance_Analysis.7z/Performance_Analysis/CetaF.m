function [C] = CetaF(eta,mu,p,ms,ga,NT)

E = (1+eta)/(1+p);

id =@(q) pochhammer(mu*p/(1+p),q)*(1-p/eta)^q*...
         (log(ga*(ms-1)/mu/E)+psi(mu+q)-psi(ms))/factorial(q);

C = zeros(1,length(ga));
for q = 0:NT
%     id(q)
    C = C + id(q);
end

C = C*(p/eta)^(mu*p/(1+p))/log(2);

end