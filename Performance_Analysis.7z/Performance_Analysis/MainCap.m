% clear all
clc

ms = 10.0;
eta = 1.0;
mu = 2.0;
p = 0.075;
NF = 1e3;
Nx = 100;
SNRb = linspace(-10,40,15);
ga = 10.^(0.1*SNRb);

ge = [];
for i = 1:Nx
    i
    ge = cat(1,ge,extendedEtaF(eta,mu,1,p,ms,NF));
end

% ge = extendedEtaF(eta,mu,1,p,ms,NF); % rc = 1 para que a SNR seja proporcional apenas a ga

C = zeros(1,length(ga));
SNR = zeros(NF*Nx,length(ga));
for i = 1:length(ga)
    SNR(:,i) = ga(i)*ge.^2;
end

C = mean(log2(1+SNR),1);

%%

Nt = 55;
ga = 10.^(0.1*linspace(min(SNRb),max(SNRb),50));
SNR = 10*log10(ga);
Ctheo1 = CetaF(eta,mu,p,ms,ga,Nt);
Ctheo2 = CapEF(eta,mu,ms,p,ga,Nt);

figure(1)
plot(SNR,Ctheo1,':',...
     SNR,Ctheo2,'--',...
     SNRb,C,'-x')
axis([0 30 -5 15])

%%
clc

% save case1
% save case2
% save case3
% save case4


