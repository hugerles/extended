clc
clear all

M = 2; % Ordem da constela��o M-QAM
N = 5e4; % N�mero de bits transmitidos
SNR_dB = linspace(0,30,15);
mu = 2;
eta = 1.0;
p = 0.075;
ms = 10;
tic

%%
ber = zeros(length(SNR_dB),length(M));
v = 1;
for m = 1:length(M)
    m;
    for i=1:length(SNR_dB)
        mi = [m i]
        [ber(i,m)] = channel(M(m),SNR_dB(i),N,eta,mu,p,ms);
    end
end

toc


%%

load('BPSK')
ga = 10.^(SNR_dB/10);
Pb =@(ga) PEBetaF(eta,mu,p,ms,ga,10,1,2);
Pbas =@(ga) AsPEBetaF(eta,mu,p,ms,ga,1,2);
figure(1)
semilogy(SNR_dB,Pb(ga),'-o',...
         SNR_dB,Pbas(ga),'-d',...
         SNR_dB,ber(:,1),'-x','linewidth',1.2)
axis([min(SNR_dB) max(SNR_dB) 1e-5 1e0])

% save case1
% save case4
% save case2
% save case3