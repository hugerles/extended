function [Pb] = PEBetaF(eta,mu,p,ms,ga,Nt,theta,phi)

E = (1+eta)/(1+p);

f =@(x,ga,i) meijerG([0.5-ms 0.5],[],mu+i-0.5,-0.5,mu*E.*x/ga/phi/(ms-1)).*exp(-x/2);
x = linspace(0,10,100);
id =@(i,ga) pochhammer(mu*p/(1+p),i).*(1-p/eta).^i*...
            trapz(x,f(x,ga,i))/...
            factorial(i)/pochhammer(mu,i);

Pb = zeros(1,length(ga));
for i = 0:Nt
    aux = zeros(1,length(ga));
    for g = 1:length(ga)
      aux(g) = id(i,ga(g));  
    end
    Pb = Pb + aux;
end

Pb = Pb*theta*(p/eta)^(mu*p/(1+p))*...
     sqrt(mu*E/2/pi/(ms-1)/phi)./sqrt(ga)/gamma(mu)/gamma(ms)/2;

end