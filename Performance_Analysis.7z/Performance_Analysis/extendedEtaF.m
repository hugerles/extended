function gain = extendedEtaF(eta,mu,rc,p,ms,NF)
% Função para geração das variáveis aleatórias da envoltória
% com distribuição de extended eta
% NF = número de frames
% Tc = tempo de coerência
% rc = potência da variável aleatória
% mu = número de agrupamentos de multipercurso
% eta = parâmetro da distribuição
% p = parâmetro que indica desbalanceamento em mu


E = (1+eta)/(1+p);

C = 2*(mu*E)^mu*(ms-1)^ms*rc^(2*ms)*(p/eta)^(mu*p/(1+p))/beta(mu,ms);

fr =@(r) mu*E*r.^2+(ms-1)*rc^2;

PDF =@(r) C*hypergeom([mu*p/(1+p) mu+ms],mu,mu*E*(eta-p)*r.^2./fr(r)/eta).*...
            r.^(2*mu-1)./(fr(r).^(mu+ms));


y = PDF(0:0.01:10);
mx = real(max(y));
if mx > 10
    mx = 10;
end

gain = zeros(NF,1);
g = [];
while length(g) <= NF
    x1 = random('unif',0,2*pi,[1 NF]);
    y = random('unif',0,mx,[1 NF]);
    [~,x] = find(y <= PDF(x1));
        g = cat(2,g,x1(x));
end


gain(:,1) = g(1:NF); % Limitando o tamanho do vetor 

% [fx,x] = histnorm(gain(:),1e2);
% e = 0:0.001:max(gain);
% 
% figure(132)
% plot(e,PDF(e),'r',...
%      x,fx,'bx',...
%      'linewidth',1.5)

end
